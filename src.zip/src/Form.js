import React,{Component} from 'react';
import './Formcss.css';
class From extends Component{

    constructor(props){
        super(props);
        this.state={
            username:"ajay123",
            useremail:"ajay@gmail.com",
            usermob:"123456",
            message:"hello nice  working"
        }
    }

    handleallchanges=(event)=>{
        this.setState({[event.target.name]:event.target.value})
    }

    handleSubmit=(event)=>{
        alert(JSON.stringify(this.state));
        event.preventDefault();
}
    render()
    {
        return(
            <div className="form">
                <form onSubmit={this.handleSubmit}>
                    <label>User ID:</label>
                    <br/>
                    <input text="text" value={this.state.username} name="username" onChange={this.handleallchanges}/>
                    <br/>
                    <label>Email ID:</label>
                    <br/>
                    <input text="email" value={this.state.useremail} name="useremail" onChange={this.handleallchanges}/>
                    <br/>
                    
                    <label>Mob No:</label>
                    <br/>
                    <input text="number" value={this.state.usermob} name="usermob" onChange={this.handleallchanges}/>
                    <br/>
                    
                    <label>Query:</label><br/>
                    <textarea value={this.state.message} name="message" onChange={this.handleallchanges}/> <br/>
                    
                    <input type="submit" value="Send"/>
                </form>
            </div>
        );
    }
}

export default From;